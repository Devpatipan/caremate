import React from 'react';
import { Stack } from 'expo-router';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from '../theme/ThemeProvider';

// --- LINE Seed Sans TH (optional) ---------------------------------------
// 1) put the .ttf files in assets/fonts/
// 2) uncomment below, 3) set FONTS_ENABLED = true in theme/fonts.ts
//
// import { useFonts } from 'expo-font';
// const [fontsLoaded] = useFonts({
//   'LINESeedSansTH-Regular': require('../assets/fonts/LINESeedSansTH-Regular.ttf'),
//   'LINESeedSansTH-Medium':  require('../assets/fonts/LINESeedSansTH-Medium.ttf'),
//   'LINESeedSansTH-Bold':    require('../assets/fonts/LINESeedSansTH-Bold.ttf'),
// });
// if (!fontsLoaded) return null;
// ------------------------------------------------------------------------

const queryClient = new QueryClient();

export default function RootLayout() {
  return (
    <QueryClientProvider client={queryClient}>
      <SafeAreaProvider>
        <ThemeProvider initialMode="system">
          <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="(tabs)" />
            <Stack.Screen name="alerts" options={{ presentation: 'card' }} />
          </Stack>
        </ThemeProvider>
      </SafeAreaProvider>
    </QueryClientProvider>
  );
}
